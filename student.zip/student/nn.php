<?php
date_default_timezone_set("Asia/Kolkata");
$date = new DateTime();
echo $date->format('Y-m-d');
?>